from models import Employee

e = Employee(name = "Dinesh",emp_id = 1,dept = "devices",eff_date = "1987-06-18")
e.save()
