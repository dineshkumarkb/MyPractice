## **Data Anonymizer**

This tool uses nlp to anonymize columns in a csv file.

By default this anonymizes 4 columns abbreviation,mapname,mapcode and personid.